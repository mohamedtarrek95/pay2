package com.example.money_transfer_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
